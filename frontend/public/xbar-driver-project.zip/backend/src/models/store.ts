import type { Mission, Driver, Vehicle, EventLogEntry, GpsPoint, OtpRecord, AuthSession } from './types';
import { v4 as uuidv4 } from 'uuid';

const now = Date.now();
const hour = 60 * 60 * 1000;
const day = 24 * hour;

export const drivers: Driver[] = [
  {
    id: 'drv-001',
    mobile: '09121234567',
    name: 'محمد رضایی',
    nationalCode: '1234567890',
    licenseNumber: 'B-12345689',
    verifiedStatus: 'verified',
    rating: 4.8,
    totalMissions: 127,
    joinedDate: '۱۴۰۲/۰۳/۱۵',
    sessionPolicy: 'no_short_expiry',
  },
];

export const vehicles: Vehicle[] = [
  {
    id: 'veh-001',
    driverId: 'drv-001',
    type: 'trailer',
    typeName: 'تریلی',
    plate: '۱۲۳-۴۵۶-۵۴',
    capacityTons: 24,
    volumeM3: 90,
    axles: 6,
    fuelType: 'دیزل',
    year: 1402,
    insuranceExpiry: '۱۴۰۴/۰۶/۳۰',
    verifiedStatus: 'verified',
    active: true,
  },
  {
    id: 'veh-002',
    driverId: 'drv-001',
    type: 'khavar',
    typeName: 'خاور',
    plate: '۴۵۶-۷۸۹-۲۲',
    capacityTons: 12,
    volumeM3: 45,
    axles: 4,
    fuelType: 'دیزل',
    year: 1400,
    insuranceExpiry: '۱۴۰۴/۰۳/۲۰',
    verifiedStatus: 'verified',
    active: false,
  },
];

export const missions: Mission[] = [
  {
    id: 'mis-1001',
    code: 'XB-1001',
    driverId: null,
    originCity: 'تهران',
    originArea: 'پاسداران',
    originLocation: { lat: 35.775, lng: 51.392 },
    destCity: 'اصفهان',
    destArea: 'مرکز',
    destExact: { lat: 32.654, lng: 51.668, address: 'میدان نقش جهان' },
    visibleDestinationExact: false,
    cargo: {
      type: 'لوازم ساختمانی',
      weightTons: 18,
      dimensions: '۶×۲.۲×۲.۵ متر',
      value: 450000000,
      packing: 'پالت',
      sensitive: false,
    },
    timeWindow: { pickupFrom: 'امروز ۱۴:۰۰', pickupTo: 'امروز ۱۸:۰۰' },
    flag: 'normal',
    status: 'Offered',
    vehicleTypeRequired: 'trailer',
    price: 18500000,
    offerExpiresAt: new Date(now + 20 * 60_000).toISOString(),
    routePlanned: { distanceKm: 450, estimatedHours: 6 },
    otpState: 'not_requested',
    photosUploaded: 0,
    podPhotos: [],
  },
  {
    id: 'mis-1002',
    code: 'XB-1002',
    driverId: 'drv-001',
    originCity: 'تهران',
    originArea: 'شهرک غرب',
    originLocation: { lat: 35.758, lng: 51.373 },
    destCity: 'شیراز',
    destArea: 'مرکز',
    destExact: { lat: 29.592, lng: 52.583, address: 'بلوار ارم، پلاک ۲۰۰' },
    visibleDestinationExact: true,
    cargo: {
      type: 'مواد غذایی فاسدشدنی',
      weightTons: 10,
      dimensions: '۴×۲×۲ متر',
      value: 320000000,
      packing: 'کارتن',
      sensitive: true,
    },
    timeWindow: { pickupFrom: 'امروز ۰۸:۰۰', pickupTo: 'امروز ۱۰:۰۰' },
    flag: 'sensitive',
    status: 'InTransit',
    vehicleTypeRequired: 'khavar',
    price: 24000000,
    driverConfirmedAt: new Date(now - 5 * hour).toISOString(),
    waybillIssuedAt: new Date(now - 3 * hour).toISOString(),
    moveStartedAt: new Date(now - 2.5 * hour).toISOString(),
    pickupEta: new Date(now - 5 * hour).toISOString(),
    routePlanned: { distanceKm: 920, estimatedHours: 12 },
    otpState: 'not_requested',
    photosUploaded: 0,
    podPhotos: [],
  },
  {
    id: 'mis-1003',
    code: 'XB-0998',
    driverId: 'drv-001',
    originCity: 'کرج',
    originArea: 'شهرک مهندسین',
    originLocation: { lat: 35.84, lng: 50.91 },
    destCity: 'مشهد',
    destArea: 'شرق',
    destExact: { lat: 36.297, lng: 59.606, address: 'بلوار وکیل‌آباد ۴۵' },
    visibleDestinationExact: true,
    cargo: {
      type: 'لوازم خانگی',
      weightTons: 8,
      dimensions: '۳×۲×۲ متر',
      value: 180000000,
      packing: 'کارتن',
      sensitive: false,
    },
    timeWindow: { pickupFrom: 'دیروز ۱۰:۰۰', pickupTo: 'دیروز ۱۴:۰۰' },
    flag: 'urgent',
    status: 'Completed',
    vehicleTypeRequired: 'truck',
    price: 16000000,
    driverConfirmedAt: new Date(now - day - 4 * hour).toISOString(),
    waybillIssuedAt: new Date(now - day - 2 * hour).toISOString(),
    moveStartedAt: new Date(now - day - 1.5 * hour).toISOString(),
    completedAt: new Date(now - 3 * hour).toISOString(),
    routePlanned: { distanceKm: 950, estimatedHours: 13 },
    otpState: 'verified',
    photosUploaded: 3,
    podPhotos: ['photo1.jpg', 'photo2.jpg', 'photo3.jpg'],
    deliveredAt: new Date(now - 3 * hour).toISOString(),
  },
  {
    id: 'mis-1004',
    code: 'XB-0990',
    driverId: 'drv-001',
    originCity: 'اصفهان',
    originArea: 'ذوب آهن',
    originLocation: { lat: 32.65, lng: 51.68 },
    destCity: 'بندرعباس',
    destArea: 'بندر',
    destExact: { lat: 27.183, lng: 56.267, address: 'اسکله ۵' },
    visibleDestinationExact: false,
    cargo: {
      type: 'میلگرد',
      weightTons: 22,
      dimensions: '۱۲×۲.۲×۲.۵ متر',
      value: 600000000,
      packing: 'بدون بسته‌بندی',
      sensitive: false,
    },
    timeWindow: { pickupFrom: '۳ روز پیش ۰۸:۰۰', pickupTo: '۳ روز پیش ۱۲:۰۰' },
    flag: 'normal',
    status: 'Cancelled',
    vehicleTypeRequired: 'trailer',
    price: 21000000,
    cancelledAt: new Date(now - 3 * day).toISOString(),
    cancelReason: 'لغو توسط اپراتور - تغییر خودرو',
    otpState: 'not_requested',
    photosUploaded: 0,
    podPhotos: [],
  },
];

export const eventLog: EventLogEntry[] = [
  { id: uuidv4(), missionId: 'mis-1002', actor: 'system', type: 'gps_update', ts: now - 10 * 60_000, metadata: { lat: 32.1, lng: 51.2 } },
  { id: uuidv4(), missionId: 'mis-1002', actor: 'system', type: 'status_change', ts: now - 2.5 * hour, metadata: { from: 'WaybillIssued', to: 'InTransit' } },
  { id: uuidv4(), missionId: 'mis-1003', actor: 'driver', type: 'pod_verified', ts: now - 3 * hour, metadata: {} },
];

export const gpsStore: Record<string, GpsPoint[]> = {};

export const otpStore: Record<string, OtpRecord> = {};

export const sessions: AuthSession[] = [];

export const pendingOtps: Record<string, { code: string; expiresAt: number }> = {};

export function findMission(id: string): Mission | undefined {
  return missions.find((m) => m.id === id);
}

export function logEvent(missionId: string, actor: EventLogEntry['actor'], type: string, metadata: Record<string, unknown> = {}): void {
  eventLog.push({ id: uuidv4(), missionId, actor, type, ts: Date.now(), metadata });
}
