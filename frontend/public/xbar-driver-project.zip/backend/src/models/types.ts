export type MissionStatus =
  | 'Offered'
  | 'Accepted'
  | 'EnRouteToPickup'
  | 'ArrivedPickup'
  | 'LoadingChecks'
  | 'WaybillIssued'
  | 'InTransit'
  | 'NearDestination'
  | 'POD'
  | 'Completed'
  | 'Declined'
  | 'Cancelled';

export type OtpState = 'not_requested' | 'requested' | 'verified' | 'otp_not_received';
export type Flag = 'normal' | 'sensitive' | 'urgent';
export type VehicleType = 'trailer' | 'khavar' | 'truck';
export type VerificationStatus = 'verified' | 'pending' | 'rejected';

export interface GpsPoint {
  lat: number;
  lng: number;
  ts: number;
  accuracy?: number;
  speed?: number;
  heading?: number;
  source?: 'online' | 'offline';
}

export interface CargoInfo {
  type: string;
  weightTons: number;
  dimensions: string;
  value: number;
  packing: string;
  sensitive: boolean;
}

export interface Mission {
  id: string;
  code: string;
  driverId: string | null;
  originCity: string;
  originArea: string;
  originLocation: { lat: number; lng: number };
  destCity: string;
  destArea: string;
  destExact: { lat: number; lng: number; address: string };
  visibleDestinationExact: boolean;
  cargo: CargoInfo;
  timeWindow: { pickupFrom: string; pickupTo: string };
  flag: Flag;
  status: MissionStatus;
  vehicleTypeRequired: VehicleType;
  price: number;
  offerExpiresAt?: string;
  routePlanned?: { distanceKm: number; estimatedHours: number };
  driverConfirmedAt?: string;
  waybillIssuedAt?: string;
  moveStartedAt?: string;
  pickupEta?: string;
  completedAt?: string;
  cancelledAt?: string;
  cancelReason?: string;
  otpState: OtpState;
  photosUploaded: number;
  podPhotos: string[];
  podExceptionReason?: string;
  deliveredAt?: string;
}

export interface Driver {
  id: string;
  mobile: string;
  name: string;
  nationalCode: string;
  licenseNumber: string;
  verifiedStatus: VerificationStatus;
  rating: number;
  totalMissions: number;
  joinedDate: string;
  sessionPolicy: 'no_short_expiry';
}

export interface Vehicle {
  id: string;
  driverId: string;
  type: VehicleType;
  typeName: string;
  plate: string;
  capacityTons: number;
  volumeM3: number;
  axles: number;
  fuelType: string;
  year: number;
  insuranceExpiry: string;
  verifiedStatus: VerificationStatus;
  active: boolean;
}

export interface EventLogEntry {
  id: string;
  missionId: string;
  actor: 'driver' | 'operator' | 'system';
  type: string;
  ts: number;
  metadata: Record<string, unknown>;
}

export interface OtpRecord {
  missionId: string;
  code: string;
  expiresAt: number;
  attempts: number;
}

export interface AuthSession {
  token: string;
  driverId: string;
  mobile: string;
  createdAt: number;
}
