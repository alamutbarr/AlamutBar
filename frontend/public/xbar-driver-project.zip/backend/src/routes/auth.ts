import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { drivers, pendingOtps } from '../models/store';
import { generateToken, validateMobile, generateOtpCode } from '../middleware/auth';

const router = Router();

const otpLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 3,
  message: { error: 'تعداد درخواست زیاد است. یک دقیقه بعد تلاش کنید.' },
});

router.post('/request-otp', otpLimiter, (req, res) => {
  const { mobile } = req.body;

  if (!mobile || !validateMobile(mobile)) {
    res.status(400).json({ error: 'شماره موبایل نامعتبر است. فرمت: 09XXXXXXXXX' });
    return;
  }

  const driver = drivers.find((d) => d.mobile === mobile);
  if (!driver) {
    res.status(404).json({ error: 'راننده‌ای با این شماره ثبت نشده است' });
    return;
  }

  const code = generateOtpCode(parseInt(process.env.OTP_CODE_LENGTH || '4', 10));
  const expiresAt = Date.now() + (parseInt(process.env.OTP_EXPIRES_IN || '120', 10) * 1000);

  pendingOtps[mobile] = { code, expiresAt };

  console.log(`[OTP] ${mobile} -> ${code} (expires in ${process.env.OTP_EXPIRES_IN || '120'}s)`);

  res.json({
    message: 'کد تأیید ارسال شد',
    expiresIn: process.env.OTP_EXPIRES_IN || 120,
  });
});

router.post('/verify-otp', (req, res) => {
  const { mobile, code } = req.body;

  if (!mobile || !code) {
    res.status(400).json({ error: 'شماره موبایل و کد الزامی است' });
    return;
  }

  const driver = drivers.find((d) => d.mobile === mobile);
  if (!driver) {
    res.status(404).json({ error: 'راننده یافت نشد' });
    return;
  }

  const record = pendingOtps[mobile];
  if (!record) {
    res.status(400).json({ error: 'کد تأیید درخواست نشده است' });
    return;
  }

  if (Date.now() > record.expiresAt) {
    delete pendingOtps[mobile];
    res.status(400).json({ error: 'کد تأیید منقضی شده است. دوباره درخواست کنید.' });
    return;
  }

  if (record.code !== code) {
    res.status(400).json({ error: 'کد تأیید اشتباه است' });
    return;
  }

  delete pendingOtps[mobile];

  const token = generateToken(driver.id, driver.mobile);

  res.json({
    token,
    session: {
      driverId: driver.id,
      name: driver.name,
      mobile: driver.mobile,
      sessionPolicy: driver.sessionPolicy,
    },
  });
});

export default router;
