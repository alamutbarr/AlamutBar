import { Router, Response } from 'express';

const router = Router();

router.get('/operator-phone', (_req, res: Response) => {
  res.json({ phone: '021-12345678', label: 'اپراتور Xbar' });
});

export default router;
