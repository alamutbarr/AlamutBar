import { Router, Response } from 'express';
import type { AuthRequest } from '../middleware/auth';
import { drivers, vehicles } from '../models/store';

const router = Router();

router.get('/profile', (req: AuthRequest, res: Response) => {
  const driver = drivers.find((d) => d.id === req.driverId);
  if (!driver) {
    res.status(404).json({ error: 'راننده یافت نشد' });
    return;
  }
  res.json({ driver });
});

router.get('/vehicles', (req: AuthRequest, res: Response) => {
  const driverVehicles = vehicles.filter((v) => v.driverId === req.driverId);
  res.json({ vehicles: driverVehicles });
});

export default router;
