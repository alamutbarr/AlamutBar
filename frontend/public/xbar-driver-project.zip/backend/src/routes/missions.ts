import { Router, Response } from 'express';
import type { AuthRequest } from '../middleware/auth';
import { missions, vehicles, eventLog, gpsStore, otpStore, findMission, logEvent } from '../models/store';
import type { Mission, MissionStatus } from '../models/types';

const router = Router();

function filterForDriver(mission: Mission, driverId: string): boolean {
  if (mission.status === 'Offered') return true;
  return mission.driverId === driverId;
}

function sanitizeMission(mission: Mission): Mission {
  if (!mission.visibleDestinationExact) {
    return {
      ...mission,
      destExact: { lat: 0, lng: 0, address: '' },
    };
  }
  return mission;
}

const VALID_TRANSITIONS: Record<MissionStatus, MissionStatus[]> = {
  Offered: ['Accepted', 'Declined', 'Cancelled'],
  Accepted: ['EnRouteToPickup', 'Cancelled'],
  EnRouteToPickup: ['ArrivedPickup', 'Cancelled'],
  ArrivedPickup: ['LoadingChecks'],
  LoadingChecks: ['WaybillIssued'],
  WaybillIssued: ['InTransit', 'Cancelled'],
  InTransit: ['NearDestination', 'Cancelled'],
  NearDestination: ['POD'],
  POD: ['Completed'],
  Completed: [],
  Declined: [],
  Cancelled: [],
};

function transition(mission: Mission, newStatus: MissionStatus): boolean {
  const allowed = VALID_TRANSITIONS[mission.status];
  if (!allowed || !allowed.includes(newStatus)) {
    return false;
  }
  const oldStatus = mission.status;
  mission.status = newStatus;
  logEvent(mission.id, 'system', 'status_change', { from: oldStatus, to: newStatus });

  if (newStatus === 'WaybillIssued') {
    mission.visibleDestinationExact = true;
    mission.waybillIssuedAt = new Date().toISOString();
  }
  if (newStatus === 'InTransit') {
    mission.moveStartedAt = new Date().toISOString();
  }
  if (newStatus === 'Accepted') {
    mission.driverConfirmedAt = new Date().toISOString();
  }
  return true;
}

router.get('/', (req: AuthRequest, res: Response) => {
  const status = (req.query.status as string) || 'all';
  const driverId = req.driverId!;

  let filtered = missions.filter((m) => filterForDriver(m, driverId));

  if (status === 'offered') {
    filtered = filtered.filter((m) => m.status === 'Offered');
  } else if (status === 'active') {
    filtered = filtered.filter((m) =>
      ['Accepted', 'EnRouteToPickup', 'ArrivedPickup', 'LoadingChecks', 'WaybillIssued', 'InTransit', 'NearDestination', 'POD'].includes(m.status)
    );
  } else if (status === 'history') {
    filtered = filtered.filter((m) => ['Completed', 'Cancelled', 'Declined'].includes(m.status));
  }

  res.json({ missions: filtered.map(sanitizeMission) });
});

router.get('/:id', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  if (!filterForDriver(mission, req.driverId!)) {
    res.status(403).json({ error: 'دسترسی غیرمجاز' });
    return;
  }
  res.json({ mission: sanitizeMission(mission) });
});

router.post('/:id/accept', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  if (mission.status !== 'Offered') {
    res.status(400).json({ error: 'این مأموریت قابل قبول نیست' });
    return;
  }
  mission.driverId = req.driverId!;
  if (!transition(mission, 'Accepted')) {
    res.status(400).json({ error: 'انتقال وضعیت نامعتبر است' });
    return;
  }
  res.json({ mission: sanitizeMission(mission) });
});

router.post('/:id/decline', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  if (mission.status !== 'Offered') {
    res.status(400).json({ error: 'این مأموریت قابل رد نیست' });
    return;
  }
  transition(mission, 'Declined');
  res.json({ message: 'مأموریت رد شد' });
});

router.post('/:id/arrive-pickup', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  if (!transition(mission, 'ArrivedPickup')) {
    res.status(400).json({ error: 'انتقال وضعیت نامعتبر است' });
    return;
  }
  res.json({ mission: sanitizeMission(mission) });
});

router.post('/:id/start-move', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  if (!transition(mission, 'InTransit')) {
    res.status(400).json({ error: 'انتقال وضعیت نامعتبر است' });
    return;
  }
  res.json({ mission: sanitizeMission(mission) });
});

router.post('/:id/near-destination', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  if (!transition(mission, 'NearDestination')) {
    res.status(400).json({ error: 'انتقال وضعیت نامعتبر است' });
    return;
  }
  res.json({ mission: sanitizeMission(mission) });
});

router.post('/:id/gps/batch', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  const points = req.body.points;
  if (!Array.isArray(points) || points.length === 0) {
    res.status(400).json({ error: 'نقاط GPS ارسال نشده است' });
    return;
  }
  if (!gpsStore[mission.id]) gpsStore[mission.id] = [];
  gpsStore[mission.id].push(...points);
  const lastPoint = points[points.length - 1];
  logEvent(mission.id, 'driver', 'gps_update', { lat: lastPoint.lat, lng: lastPoint.lng, count: points.length });
  res.json({ message: 'نقاط GPS ذخیره شد', count: points.length, total: gpsStore[mission.id].length });
});

router.get('/:id/gps/status', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  const points = gpsStore[mission.id] || [];
  const lastPoint = points.length > 0 ? points[points.length - 1] : null;
  const lastTs = lastPoint ? lastPoint.ts : 0;
  const offlineLong = Date.now() - lastTs > 12 * 60 * 60 * 1000;

  res.json({
    status: lastPoint ? (offlineLong ? 'offline_long' : 'active') : 'disconnected',
    lastPoint,
    totalPoints: points.length,
  });
});

router.post('/:id/pod/request-otp', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  if (mission.status !== 'NearDestination' && mission.status !== 'POD') {
    res.status(400).json({ error: 'درخواست OTP فقط در نزدیک مقصد مجاز است' });
    return;
  }
  if (mission.status === 'NearDestination') {
    transition(mission, 'POD');
  }
  const code = Math.floor(1000 + Math.random() * 9000).toString();
  const expiresAt = Date.now() + 120_000;
  otpStore[mission.id] = { missionId: mission.id, code, expiresAt, attempts: 0 };
  mission.otpState = 'requested';
  console.log(`[POD-OTP] Mission ${mission.code} -> ${code}`);
  logEvent(mission.id, 'driver', 'pod_otp_requested', {});
  res.json({ message: 'کد تحویل برای تحویل‌گیرنده ارسال شد', expiresIn: 120 });
});

router.post('/:id/pod/upload-photos', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  const photos = req.body.photos;
  if (!Array.isArray(photos) || photos.length < 3) {
    res.status(400).json({ error: 'حداقل ۳ عکس الزامی است' });
    return;
  }
  mission.podPhotos = photos;
  mission.photosUploaded = photos.length;
  logEvent(mission.id, 'driver', 'pod_photos_uploaded', { count: photos.length });
  res.json({ message: 'عکس‌ها ثبت شد', count: photos.length });
});

router.post('/:id/pod/verify-otp', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  const { code } = req.body;
  if (!code) {
    res.status(400).json({ error: 'کد الزامی است' });
    return;
  }
  const record = otpStore[mission.id];
  if (!record) {
    res.status(400).json({ error: 'کد تحویل درخواست نشده است' });
    return;
  }
  if (Date.now() > record.expiresAt) {
    delete otpStore[mission.id];
    res.status(400).json({ error: 'کد منقضی شده است' });
    return;
  }
  record.attempts++;
  if (record.code !== code) {
    if (record.attempts >= 5) {
      delete otpStore[mission.id];
      mission.otpState = 'not_requested';
      res.status(400).json({ error: 'تعداد تلاش بیش از حد. دوباره درخواست کد کنید.' });
      return;
    }
    res.status(400).json({ error: `کد اشتباه است. تلاش ${record.attempts} از ۵` });
    return;
  }
  delete otpStore[mission.id];
  mission.otpState = 'verified';
  mission.deliveredAt = new Date().toISOString();
  transition(mission, 'Completed');
  logEvent(mission.id, 'driver', 'pod_verified', {});
  res.json({ message: 'تحویل ثبت شد. مأموریت تکمیل شد.', mission: sanitizeMission(mission) });
});

router.post('/:id/pod/otp-not-received', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  const { reason } = req.body;
  if (!reason) {
    res.status(400).json({ error: 'دلیل دریافت نشدن OTP الزامی است' });
    return;
  }
  mission.otpState = 'otp_not_received';
  mission.podExceptionReason = reason;
  logEvent(mission.id, 'driver', 'pod_otp_not_received', { reason });
  res.json({ message: 'هشدار به اپراتور ارسال شد. در انتظار تأیید تحویل بدون OTP.' });
});

router.post('/:id/events/log', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  const { type, payload } = req.body;
  if (!type) {
    res.status(400).json({ error: 'نوع رویداد الزامی است' });
    return;
  }
  logEvent(mission.id, 'driver', type, payload || {});
  res.json({ message: 'رویداد ثبت شد' });
});

router.get('/:id/events', (req: AuthRequest, res: Response) => {
  const mission = findMission(req.params.id);
  if (!mission || mission.driverId !== req.driverId) {
    res.status(404).json({ error: 'مأموریت یافت نشد' });
    return;
  }
  const events = eventLog.filter((e) => e.missionId === mission.id);
  res.json({ events });
});

export default router;
