import type { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'xbar-driver-secret-change-in-production';

export interface AuthRequest extends Request {
  driverId?: string;
  mobile?: string;
}

export function generateToken(driverId: string, mobile: string): string {
  return jwt.sign({ driverId, mobile }, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  } as jwt.SignOptions);
}

export function authMiddleware(req: AuthRequest, res: Response, next: NextFunction): void {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    res.status(401).json({ error: 'توکن احراز هویت ارسال نشده است' });
    return;
  }

  const token = header.slice(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { driverId: string; mobile: string };
    req.driverId = decoded.driverId;
    req.mobile = decoded.mobile;
    next();
  } catch {
    res.status(401).json({ error: 'توکن نامعتبر یا منقضی شده است' });
  }
}

export function validateMobile(mobile: string): boolean {
  return /^09\d{9}$/.test(mobile);
}

export function generateOtpCode(length: number = 4): string {
  let code = '';
  for (let i = 0; i < length; i++) {
    code += Math.floor(Math.random() * 10).toString();
  }
  return code;
}
