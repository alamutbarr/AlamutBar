import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import authRoutes from './routes/auth';
import missionRoutes from './routes/missions';
import driverRoutes from './routes/driver';
import supportRoutes from './routes/support';
import { authMiddleware } from './middleware/auth';

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '10mb' }));
app.use(morgan('dev'));

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'xbar-driver-backend', timestamp: new Date().toISOString() });
});

app.use('/auth', authRoutes);
app.use('/support', supportRoutes);
app.use('/driver', authMiddleware, driverRoutes);
app.use('/driver/missions', authMiddleware, missionRoutes);

app.use((_req, res) => {
  res.status(404).json({ error: 'مسیر یافت نشد' });
});

app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[ERROR]', err.message);
  res.status(500).json({ error: 'خطای داخلی سرور' });
});

app.listen(PORT, () => {
  console.log(`[Xbar Driver Backend] running on http://localhost:${PORT}`);
});
