import { useState } from 'react';
import { useOtpAuth } from '@/driver/hooks/useOtpAuth';
import {
  Truck,
  Phone,
  KeyRound,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  ShieldCheck,
} from 'lucide-react';

export function DriverLogin({ onLogin }: { onLogin: () => void }) {
  const { state, requestOtp, verifyOtp, setCode } = useOtpAuth();
  const [mobile, setMobile] = useState('');
  const [verifying, setVerifying] = useState(false);

  const handleSendOtp = () => {
    if (requestOtp(mobile)) {
      // OTP sent (simulated)
    }
  };

  const handleVerify = async () => {
    setVerifying(true);
    const ok = await verifyOtp(state.code);
    setVerifying(false);
    if (ok) {
      setTimeout(onLogin, 300);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      {/* Decorative background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-blue-500/10 blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-emerald-500/10 blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-500/30 mb-4">
            <Truck className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Xbar راننده</h1>
          <p className="text-sm text-slate-400 mt-1">پنل رانندگان خودروهای سنگین</p>
        </div>

        {/* Card */}
        <div className="rounded-3xl bg-white/95 backdrop-blur-xl shadow-2xl p-6 sm:p-8">
          {state.step === 'idle' && (
            <>
              <h2 className="text-lg font-bold text-slate-800 mb-1">ورود به پنل</h2>
              <p className="text-sm text-slate-500 mb-5">
                شماره موبایل خود را وارد کنید تا کد تأیید ارسال شود
              </p>

              <label className="block text-sm font-medium text-slate-700 mb-2">
                شماره موبایل
              </label>
              <div className="relative mb-4">
                <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="tel"
                  inputMode="numeric"
                  value={mobile}
                  onChange={(e) => {
                    setMobile(e.target.value.replace(/\D/g, ''));
                    state.error && setCode('');
                  }}
                  placeholder="09xxxxxxxxx"
                  maxLength={11}
                  dir="ltr"
                  className="w-full rounded-xl border-2 border-slate-200 bg-white py-3.5 pr-11 pl-4 text-base font-medium tracking-wide text-slate-800 focus:outline-none focus:border-blue-500 transition"
                  onKeyDown={(e) => e.key === 'Enter' && handleSendOtp()}
                />
              </div>

              {state.error && (
                <p className="text-sm text-red-500 mb-3">{state.error}</p>
              )}

              <button
                onClick={handleSendOtp}
                disabled={mobile.length < 11}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3.5 text-base font-bold text-white transition hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]"
              >
                ارسال کد تأیید
                <ArrowLeft className="w-5 h-5" />
              </button>

              <div className="mt-5 flex items-center gap-2 text-xs text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                ورود امن با تأیید شماره موبایل (OTP)
              </div>
            </>
          )}

          {state.step === 'sent' && (
            <>
              <div className="mb-5">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-blue-50 mb-3">
                  <KeyRound className="w-6 h-6 text-blue-600" />
                </div>
                <h2 className="text-lg font-bold text-slate-800 mb-1">کد تأیید را وارد کنید</h2>
                <p className="text-sm text-slate-500">
                  کد ۴ رقمی به شماره
                  <span className="font-bold text-slate-700 mx-1" dir="ltr">{state.mobile}</span>
                  ارسال شد
                </p>
                <p className="mt-2 text-xs text-slate-400">
                  کد تستی: <span className="font-bold text-blue-600" dir="ltr">1234</span>
                </p>
              </div>

              <input
                type="tel"
                inputMode="numeric"
                maxLength={4}
                value={state.code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                placeholder="----"
                dir="ltr"
                className="w-full text-center text-3xl font-bold tracking-[0.5em] rounded-xl border-2 border-slate-200 bg-white py-4 mb-4 focus:outline-none focus:border-blue-500 transition"
                onKeyDown={(e) => e.key === 'Enter' && state.code.length === 4 && handleVerify()}
                autoFocus
              />

              {state.error && (
                <p className="text-sm text-red-500 mb-3">{state.error}</p>
              )}

              <button
                onClick={handleVerify}
                disabled={state.code.length < 4 || verifying}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-green-600 px-4 py-3.5 text-base font-bold text-white transition hover:bg-green-700 disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]"
              >
                {verifying ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    در حال تأیید...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-5 h-5" />
                    تأیید و ورود
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  setMobile('');
                  setCode('');
                  requestOtp('');
                  window.location.reload();
                }}
                className="mt-4 w-full text-center text-sm text-slate-500 hover:text-slate-700"
              >
                تغییر شماره موبایل
              </button>
            </>
          )}
        </div>

        <p className="mt-6 text-center text-xs text-slate-500">
          با ورود، قوانین و مقررات Xbar را می‌پذیرید
        </p>
      </div>
    </div>
  );
}
