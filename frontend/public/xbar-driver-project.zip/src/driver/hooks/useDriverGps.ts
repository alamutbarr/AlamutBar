import { useState, useEffect, useCallback, useRef } from 'react';
import type { GpsPoint, GpsStatus } from '@/driver/types';
import { GpsQueue } from '@/driver/gpsQueue';

export function useDriverGps(enabled: boolean, missionId: string | null) {
  const [status, setStatus] = useState<GpsStatus>('active');
  const [currentPoint, setCurrentPoint] = useState<GpsPoint | null>(null);
  const [queueSize, setQueueSize] = useState(0);
  const queueRef = useRef<GpsQueue | null>(null);
  const watchIdRef = useRef<number | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    queueRef.current = new GpsQueue();
    setQueueSize(queueRef.current.size());
  }, []);

  const sendBatch = useCallback(() => {
    if (!queueRef.current) return;
    const batch = queueRef.current.getBatch(20);
    if (batch.length > 0) {
      // In real app: POST to /driver/missions/{id}/gps/batch
      queueRef.current.removeBatch(batch.length);
      setQueueSize(queueRef.current.size());
    }
  }, []);

  useEffect(() => {
    if (!enabled || !missionId) {
      if (watchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    if (!navigator.geolocation) {
      setStatus('disconnected');
      return;
    }

    const onSuccess = (pos: GeolocationPosition) => {
      const point: GpsPoint = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        ts: Date.now(),
        accuracy: pos.coords.accuracy,
        speed: pos.coords.speed ?? undefined,
        heading: pos.coords.heading ?? undefined,
        source: navigator.onLine ? 'online' : 'offline',
      };
      setCurrentPoint(point);
      queueRef.current?.add(point);
      setQueueSize(queueRef.current?.size() ?? 0);
      setStatus('active');
    };

    const onError = () => {
      setStatus('issue');
    };

    // Foreground tracking: watch position + interval fallback
    watchIdRef.current = navigator.geolocation.watchPosition(onSuccess, onError, {
      enableHighAccuracy: true,
      timeout: 15000,
      maximumAge: 30000,
    });

    // Interval-based send every 30-60s (we use 30s)
    intervalRef.current = setInterval(() => {
      sendBatch();
    }, 30000);

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [enabled, missionId, sendBatch]);

  const toggleGps = useCallback(() => {
    if (status === 'active') {
      setStatus('disconnected');
    } else {
      setStatus('active');
    }
  }, [status]);

  return { status, currentPoint, queueSize, toggleGps, sendBatch };
}
