// ===== Driver Panel Types =====

export type DriverStatus = 'online' | 'offline' | 'busy';

export type VerificationStatus = 'verified' | 'pending' | 'rejected';

export type VehicleType = 'truck' | 'trailer' | 'khavar' | 'other';

export type MissionFlag = 'normal' | 'sensitive' | 'urgent';

export type MissionStatus =
  | 'Offered'
  | 'Accepted'
  | 'EnRouteToPickup'
  | 'ArrivedPickup'
  | 'LoadingChecks'
  | 'WaybillIssued'
  | 'InTransit'
  | 'NearDestination'
  | 'POD'
  | 'Completed'
  | 'Declined'
  | 'Cancelled';

export type GpsStatus = 'active' | 'issue' | 'disconnected' | 'offline_long';

export interface Driver {
  id: string;
  mobile: string;
  name: string;
  nationalCode: string;
  licenseNumber: string;
  verifiedStatus: VerificationStatus;
  avatarUrl?: string;
  rating: number;
  totalMissions: number;
  joinedDate: string;
  sessionPolicy: 'persistent';
}

export interface Vehicle {
  id: string;
  type: VehicleType;
  typeName: string;
  plate: string;
  capacityTons: number;
  volumeM3: number;
  verifiedStatus: VerificationStatus;
  active: boolean;
  techSpec: {
    axleCount: number;
    fuelType: string;
    year: number;
    insuranceExpiry: string;
  };
}

export interface CargoInfo {
  type: string;
  weightTons: number;
  dimensions: string;
  value: number;
  packing: string;
  sensitive: boolean;
}

export interface Mission {
  id: string;
  code: string;
  originCity: string;
  originArea: string;
  originLocation: { lat: number; lng: number };
  destCity: string;
  destArea: string;
  destExact: { lat: number; lng: number; address: string };
  visibleDestinationExact: boolean;
  cargo: CargoInfo;
  timeWindow: {
    pickupFrom: string;
    pickupTo: string;
  };
  flag: MissionFlag;
  status: MissionStatus;
  vehicleTypeRequired: VehicleType;
  price?: number;
  pickupEta?: string;
  driverConfirmedAt?: string;
  waybillIssuedAt?: string;
  moveStartedAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  cancelReason?: string;
  otpState: 'not_requested' | 'requested' | 'verified' | 'not_received';
  photosUploaded: number;
  podExceptionReason?: string;
  offerExpiresAt?: string;
  routePlanned?: { distanceKm: number; estimatedHours: number };
}

export interface GpsPoint {
  lat: number;
  lng: number;
  ts: number;
  accuracy?: number;
  speed?: number;
  heading?: number;
  source: 'online' | 'offline';
}

export interface EventLogEntry {
  id: string;
  missionId: string;
  type: string;
  ts: number;
  metadata?: Record<string, unknown>;
}

export interface PodPhoto {
  id: string;
  url: string;
  label: string;
}

export type TabKey = 'offered' | 'active' | 'history';
