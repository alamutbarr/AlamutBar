import { useState, useCallback } from 'react';
import type { Mission, MissionStatus } from '@/driver/types';
import { mockDriver, mockVehicles, mockMissions } from '@/driver/mockData';
import { DriverLogin } from '@/driver/pages/DriverLogin';
import { DriverDashboard } from '@/driver/pages/DriverDashboard';
import { DriverMissions } from '@/driver/pages/DriverMissions';
import { DriverMissionDetail } from '@/driver/pages/DriverMissionDetail';
import { DriverProfile } from '@/driver/pages/DriverProfile';
import { DriverVehicles } from '@/driver/pages/DriverVehicles';
import { DriverLayout, type DriverPage } from '@/driver/layouts/DriverLayout';
import type { GpsStatus } from '@/driver/types';

type View = { page: DriverPage } | { page: 'detail'; mission: Mission };

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [missions, setMissions] = useState<Mission[]>(mockMissions);
  const [view, setView] = useState<View>({ page: 'dashboard' });
  const [gpsStatus] = useState<GpsStatus>('active');

  const handleLogin = useCallback(() => {
    setLoggedIn(true);
    setView({ page: 'dashboard' });
  }, []);

  const handleLogout = useCallback(() => {
    setLoggedIn(false);
    setView({ page: 'dashboard' });
  }, []);

  const handleNavigate = useCallback((page: DriverPage) => {
    setView({ page });
  }, []);

  const handleMissionClick = useCallback((mission: Mission) => {
    setView({ page: 'detail', mission });
  }, []);

  const handleBack = useCallback(() => {
    setView({ page: 'missions' });
  }, []);

  const updateMissionStatus = useCallback((id: string, status: MissionStatus, extra?: Partial<Mission>) => {
    setMissions((prev) =>
      prev.map((m) =>
        m.id === id
          ? { ...m, status, visibleDestinationExact: status === 'WaybillIssued' || status === 'InTransit' || status === 'NearDestination' || status === 'POD' || status === 'Completed' ? true : m.visibleDestinationExact, ...extra }
          : m
      )
    );
  }, []);

  const handleAccept = useCallback((m: Mission) => {
    updateMissionStatus(m.id, 'Accepted', { driverConfirmedAt: new Date().toISOString() });
    const updated = missions.find((x) => x.id === m.id);
    if (updated) setView({ page: 'detail', mission: { ...updated, status: 'Accepted' } });
  }, [missions, updateMissionStatus]);

  const handleDecline = useCallback((m: Mission) => {
    updateMissionStatus(m.id, 'Declined');
    setView({ page: 'missions' });
  }, [updateMissionStatus]);

  const handleAction = useCallback((m: Mission, action: string) => {
    const statusMap: Record<string, MissionStatus> = {
      en_route: 'EnRouteToPickup',
      arrived_pickup: 'ArrivedPickup',
      start_move: 'InTransit',
    };
    const newStatus = statusMap[action];
    if (newStatus) {
      updateMissionStatus(m.id, newStatus, {
        moveStartedAt: action === 'start_move' ? new Date().toISOString() : undefined,
      });
      setView({ page: 'detail', mission: { ...m, status: newStatus } });
    }
  }, [updateMissionStatus]);

  const handlePodComplete = useCallback((m: Mission, _result: { otpVerified: boolean; photosUploaded: number; exceptionReason?: string }) => {
    updateMissionStatus(m.id, 'Completed', {
      completedAt: new Date().toISOString(),
      photosUploaded: _result.photosUploaded,
      otpState: _result.otpVerified ? 'verified' : 'not_received',
      podExceptionReason: _result.exceptionReason,
    });
    setView({ page: 'detail', mission: { ...m, status: 'Completed' } });
  }, [updateMissionStatus]);

  if (!loggedIn) {
    return <DriverLogin onLogin={handleLogin} />;
  }

  const currentDetailMission = view.page === 'detail' ? missions.find((m) => m.id === view.mission.id) ?? view.mission : null;

  return (
    <DriverLayout
      current={view.page === 'detail' ? 'missions' : view.page}
      onNavigate={handleNavigate}
      onLogout={handleLogout}
      driverName={mockDriver.name}
    >
      {view.page === 'dashboard' && (
        <DriverDashboard
          driver={mockDriver}
          vehicles={mockVehicles}
          missions={missions}
          gpsStatus={gpsStatus}
          onNavigate={handleNavigate}
          onMissionClick={handleMissionClick}
        />
      )}
      {view.page === 'missions' && (
        <DriverMissions
          missions={missions}
          onMissionClick={handleMissionClick}
        />
      )}
      {view.page === 'vehicles' && <DriverVehicles vehicles={mockVehicles} />}
      {view.page === 'profile' && (
        <DriverProfile driver={mockDriver} vehicles={mockVehicles} onLogout={handleLogout} />
      )}
      {view.page === 'detail' && currentDetailMission && (
        <DriverMissionDetail
          mission={currentDetailMission}
          onBack={handleBack}
          onAccept={handleAccept}
          onDecline={handleDecline}
          onAction={handleAction}
          onPodComplete={handlePodComplete}
        />
      )}
    </DriverLayout>
  );
}
